/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modele;

import java.util.concurrent.atomic.AtomicInteger;

/**
 *
 * @author margauxhery
 */
public class Personne {
     //Attributs
    public int IdPersonne;
    private String nom;
    public String prenom;
    public String login;
    public String password;
    public String type;
    
    //Constructeur 0
    public Personne(){
        IdPersonne = 0;
        nom = null;
        prenom = null;
        login = null;
        password=null;
        type=null;
    }
    
    //Constructeur 1 
    public Personne(int IdPersonne, String nom, String prenom, String login, String password, String type){
        this.IdPersonne=IdPersonne;
        this.nom=nom;
        this.prenom=prenom;
        this.password=password;
        this.login=login;
        this.type=type;
    }
    
    //Getters
    public int getIdPersonne(){
        return IdPersonne;
    }
    public String getnom(){
        return nom;
    }
    public String getprenom(){
        return prenom;
    }
    public String getlogin(){
        return login;
    }
    public String getpassword(){
        return password;
    }
    public String gettype(){
        return type;
    }
    
    
    //Setters
    public void setPersonne(int newIdPersonne){
        IdPersonne = newIdPersonne;
    }
    public void setPersonnenom(String newnom){
        nom = newnom;
    }
    public void setPersonneprenom(String newprenom){
        prenom = newprenom;
    }
    public void setlogin(String newlogin){
        login= newlogin;
    }
    public void setpassword(String newpassword){
        password=newpassword;
    }
    public void settype(String newtype){
        type=newtype;
    }
}
