/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modele;

/**
 *
 * @author margauxhery
 */
public class Niveau {
    //Attributs
    public int IdNiveau;
    private String nom;
    
    //Constructeur 0
    public Niveau(){
        IdNiveau = 0;
        nom = null;
    }
    
    //Constructeur 1 
    public Niveau(int IdNiveau, String nom){
        this.IdNiveau=IdNiveau;
        this.nom=nom;
    }

    public Niveau(String Id_Niveau, String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    //Getters
    public int getIdNiveau(){
        return IdNiveau;
    }
    public String getnom(){
        return nom;
    }
    
    
    //Setters
    public void setNiveaue(int newIdNiveau){
        IdNiveau = newIdNiveau;
    }
    public void setNiveau(String newnom){
        nom = newnom;
    }
    
    
}
