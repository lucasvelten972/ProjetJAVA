/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modele;

/**
 *
 * @author margauxhery
 */
public class Discipline {
     //Attributs
    public int IdDiscipline;
    private String nomdiscipline;
    
    //Constructeur 0
    public Discipline(){
        IdDiscipline = 0;
        nomdiscipline = null;
    }
    
    //Constructeur 1 
    public Discipline(int IdDiscipline, String nomdiscipline){
        this.IdDiscipline=IdDiscipline;
        this.nomdiscipline = nomdiscipline;
    }
    
    //Getters
    public int getIdDiscipline(){
        return IdDiscipline;
    }
    public String getnomdiscipline(){
        return nomdiscipline;
    }
    
    
    //Setters
    public void setDiscipline(int newIdDiscipline){
        IdDiscipline = newIdDiscipline;
    }
    public void setDiscipline(String newnomdiscipline){
        nomdiscipline = newnomdiscipline;
    }
}
