/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modele;

/**
 *
 * @author margauxhery
 */
public class Ecole {
    public int IdEcole;
    public String NomEcole;
    
    //Constructeur0
    public Ecole(){
        IdEcole=0;
        NomEcole=null;
    }
    //Constructeur1
    public Ecole(int IdEcole, String nomEcole){
        this.IdEcole=IdEcole;
        this.NomEcole=nomEcole;
    }
    
    //Getters et Setters
    public void setEcole(int newIdEcole){
        IdEcole = newIdEcole;
    }
    public void setEcole(String newnomEcole){
        NomEcole = newnomEcole;
    }
    public int getIdEcole(){
        return IdEcole;
    }
    public String getnomEcole(){
        return NomEcole;
    }
}
