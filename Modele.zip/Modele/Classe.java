/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modele;

/**
 *
 * @author margauxhery
 */
public class Classe {
    //Attributs
    public int IdClasse;
    private int IdNiveau;
    private int IdAnneeScolaire;
    private String nom;
    
    //Constructeur 0
    public Classe(){
        IdClasse = 0;
        IdNiveau = 0;
        IdAnneeScolaire=0;
        nom = null;
    }
    
    //Constructeur 1 
    public Classe(int IdClasse, String nom, int IdNiveau,int IdAnneeScolaire){
        this.IdClasse=IdClasse ;
        this.IdAnneeScolaire=IdAnneeScolaire;
        this.IdNiveau=IdNiveau;
        this.nom=nom;
    }

    
    //Getters
    public int getIdClasse(){
        return IdClasse;
    }
    public int getIdNiveau(){
        return IdNiveau;
    }
    public int getIdAnneeScolaire(){
        return IdAnneeScolaire;
    }
    public String getnom(){
        return nom;
    }
    
    
    //Setters
    public void setClasse(int newIdClasse){
        IdClasse = newIdClasse;
    }
    public void setClasseNiv(int newIdNiveau){
        IdNiveau = newIdNiveau;
    }
    public void setClasseAS(int newIdAnneeScolaire){
        IdAnneeScolaire = newIdAnneeScolaire;
    }
    public void setnom(String newnom){
        nom = newnom;
    }
    
    
    
}

  
