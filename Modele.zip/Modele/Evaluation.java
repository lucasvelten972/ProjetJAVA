/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modele;

/**
 *
 * @author margauxhery
 */
public class Evaluation {
     //Attributs
    public int IdEvaluation;
    private int IdDetailsBulletin;
    private String Appreciation;
    public float Note;
    
    //Constructeur 0
    public Evaluation(){
        IdEvaluation = 0;
        IdDetailsBulletin=0;
        Appreciation = null;
        Note = 0.0f;
    }
    
    //Constructeur 1 
    public Evaluation(int IdEvaluation, int IdDetailsBulletin, float Note, String Appreciation ){
        this.IdEvaluation=IdEvaluation;
        this.IdDetailsBulletin=IdDetailsBulletin;
        this.Appreciation=Appreciation;
        this.Note=Note;
    }

    
    
    //Getters
    public int getIdEvaluation(){
        return IdEvaluation;
    }
    public int getIdDetailsBulletin(){
        return IdDetailsBulletin;
    }
    public String getAppreciation(){
        return Appreciation;
    }
    public float getNote(){
        return Note;
    }
    
    
    //Setters
    public void setEvaluation(int newIdEvaluation){
        IdEvaluation = newIdEvaluation;
    }
    public void setEvaluationDetBul(int newIdDetailsBulletin){
        IdDetailsBulletin=newIdDetailsBulletin;
    }
    public void setEvaluation(String newAppreciation){
        Appreciation = newAppreciation;
    }
    public void setEvaluation(float newNote){
        Note = newNote;
    }
    
}
