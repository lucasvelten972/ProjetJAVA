/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;


import Modele.Discipline;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
/**
 *
 * @author margauxhery
 */
public class DisciplineDAO extends DAO<Discipline>{

    public DisciplineDAO(Connection conn) throws SQLException, ClassNotFoundException{
        super(conn);
    }

    @Override
    public boolean creer(Discipline obj) {
         try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "INSERT INTO Discipline(IdDiscipline,nomdiscipline) VALUES(?,?)"
            );
            //Changer les ? par la valeur de l'objet créé pour adapter le java a la requette SQL.
            statement.setObject(1, obj.getIdDiscipline(), Types.INTEGER);
            statement.setObject(2, obj.getnomdiscipline(), Types.VARCHAR);

            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

    } catch (SQLException e) {
    }
        return true;
    }
    

    @Override
    public boolean supprimer(Discipline obj) {
        try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "DELETE FROM Discipline WHERE IdDiscipline=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.getIdDiscipline(), Types.INTEGER);
            statement.setObject(2, obj.getnomdiscipline(), Types.VARCHAR);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

    } catch (SQLException e) {
    }
        return true;
    }

    @Override
    public boolean actualiser(Discipline obj) {
     try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "UPDATE Discipline SET nomdiscipline=?, WHERE IdDiscipline=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.getIdDiscipline(), Types.INTEGER);
            statement.setObject(2, obj.getnomdiscipline(), Types.VARCHAR);
            
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

    } catch (SQLException e) {
    }
        return true;}

    @Override
    public Discipline trouver(int id) {
       Discipline discipline = new Discipline();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM Discipline WHERE IdDiscipline = " + id);
      if(result.first())
        discipline = new Discipline(
            id,
            result.getString("nomdiscipline")
        );         
    } catch (SQLException e) {
    }
    return discipline;
    }
}
    
