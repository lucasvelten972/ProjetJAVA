/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Modele.Inscription;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 *
 * @author margauxhery
 */
public class InscriptionDAO extends DAO<Inscription>{

    public InscriptionDAO(Connection conn) throws SQLException, ClassNotFoundException {
        super(conn);
    }

    @Override
    public boolean creer(Inscription obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "INSERT INTO Inscription(IdInscription,IdClasse, IdPersonne) VALUES(?,?,?)"
            );
            //Changer les ? par la valeur de l'objet créé pour adapter le java a la requette SQL.
            statement.setObject(1, obj.getIdInscription(), Types.INTEGER);
            statement.setObject(2, obj.getIdClasse(), Types.INTEGER);
            statement.setObject(3, obj.getIdPersonne(), Types.INTEGER);

            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

    } catch (SQLException e) {
    }
        return true;
    
    
    
    }

    @Override
    public boolean supprimer(Inscription obj) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "DELETE FROM Inscription WHERE IdInscription=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.getIdInscription(), Types.INTEGER);
            statement.setObject(2, obj.getIdClasse(), Types.INTEGER);
            statement.setObject(3, obj.getIdPersonne(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

    } catch (SQLException e) {
    }
        return true;
    
    
    
    }

    @Override
    public boolean actualiser(Inscription obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    
     
    
    }

    @Override
    public Inscription trouver(int id) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    Inscription inscription = new Inscription();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM Inscription WHERE IdInscription = " + id);
      if(result.first())
        inscription = new Inscription(id, result.getInt("IdClasse"), result.getInt("IdPersonne"));         
    } catch (SQLException e) {
    }
    return inscription;
    
    
    
    
    }
    
}
