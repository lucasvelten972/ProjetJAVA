/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Modele.Classe;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 *
 * @author margauxhery
 */
public class ClasseDAO extends DAO<Classe>{

    public ClasseDAO(Connection conn) throws SQLException, ClassNotFoundException {
        super(conn);
    }

    @Override
    public boolean creer(Classe obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
     try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "INSERT INTO Classe(IdClasse,nom, IdNiveau, IdAnneeScolaire) VALUES(?,?,?,?)"
            );
            //Changer les ? par la valeur de l'objet créé pour adapter le java a la requette SQL.
            statement.setObject(1, obj.getIdClasse(), Types.INTEGER);
            statement.setObject(2, obj.getnom(), Types.VARCHAR);
            statement.setObject(3, obj.getIdNiveau(), Types.INTEGER);
            statement.setObject(4, obj.getIdAnneeScolaire(), Types.INTEGER);

            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

    } catch (SQLException e) {
    }
        return true;
    
    
    }

    @Override
    public boolean supprimer(Classe obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "DELETE FROM Classe WHERE IdClasse=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.getIdClasse(), Types.INTEGER);
            statement.setObject(2, obj.getnom(), Types.VARCHAR);
            statement.setObject(3, obj.getIdNiveau(), Types.INTEGER);
            statement.setObject(4, obj.getIdAnneeScolaire(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

    } catch (SQLException e) {
    }
        return true;
    
    
    }

    @Override
    public boolean actualiser(Classe obj) {
      //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "UPDATE Classe SET nom=?, IdNiveau=?, IdAnneeScolaire=? WHERE IdClasse=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.getIdClasse(), Types.INTEGER);
            statement.setObject(2, obj.getnom(), Types.VARCHAR);
            statement.setObject(3, obj.getIdNiveau(), Types.INTEGER);
            statement.setObject(4, obj.getIdAnneeScolaire(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

    } catch (SQLException e) {
    }
        return true;
    
    
    }

    @Override
    public Classe trouver(int id) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
     Classe classe = new Classe();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM Classe WHERE IdClasse = " + id);
      if(result.first())
        classe = new Classe(
            id,
            result.getString("nom"),
            result.getInt("IdNiveau"),
            result.getInt("IdAnneeScolaire")
        );         
    } catch (SQLException e) {
    }
    return classe;
    
    }
    
}
