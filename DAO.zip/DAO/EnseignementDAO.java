/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Modele.Enseignement;
import java.sql.Connection;
import java.sql.SQLException;

/**
 *
 * @author margauxhery
 */
public class EnseignementDAO extends DAO<Enseignement>{

    public EnseignementDAO(Connection conn) throws SQLException, ClassNotFoundException {
        super(conn);
    }

    @Override
    public boolean creer(Enseignement obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean supprimer(Enseignement obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualiser(Enseignement obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Enseignement trouver(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
