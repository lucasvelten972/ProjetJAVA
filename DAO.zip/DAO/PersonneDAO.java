/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Modele.Personne;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 *
 * @author margauxhery
 */
public class PersonneDAO extends DAO<Personne>{

    public PersonneDAO(Connection conn) throws SQLException, ClassNotFoundException {
        super(conn);
    }

    @Override
    public boolean creer(Personne obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "INSERT INTO Personne(IdPersonne,nom, prenom, login, password, type) VALUES(?,?,?,?,?)"
            );
            //Changer les ? par la valeur de l'objet créé pour adapter le java a la requette SQL.
            statement.setObject(1, obj.getIdPersonne(), Types.INTEGER);
            statement.setObject(2, obj.getnom(), Types.VARCHAR);
            statement.setObject(3, obj.getprenom(), Types.VARCHAR);
            statement.setObject(4, obj.getlogin(), Types.VARCHAR);
            statement.setObject(5, obj.getpassword(), Types.VARCHAR);
            statement.setObject(6, obj.gettype(), Types.VARCHAR);

            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

    } catch (SQLException e) {
    }
        return true;
    
    
    }

    @Override
    public boolean supprimer(Personne obj) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "DELETE FROM Personne WHERE IdPersonne=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.getIdPersonne(), Types.INTEGER);
            statement.setObject(2, obj.getnom(), Types.VARCHAR);
            statement.setObject(3, obj.getprenom(), Types.VARCHAR);
            statement.setObject(4, obj.getlogin(), Types.VARCHAR);
            statement.setObject(5, obj.getpassword(), Types.VARCHAR);
            statement.setObject(6, obj.gettype(), Types.VARCHAR);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

    } catch (SQLException e) {
    }
        return true;
    
    
    }

    @Override
    public boolean actualiser(Personne obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
      try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "UPDATE Personne SET , nom=?, prenom=?, login=?, password=?, type=? WHERE IdPersonne=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.getIdPersonne(), Types.INTEGER);
            statement.setObject(2, obj.getnom(), Types.VARCHAR);
            statement.setObject(3, obj.getprenom(), Types.VARCHAR);
            statement.setObject(4, obj.getlogin(), Types.VARCHAR);
            statement.setObject(5, obj.getpassword(), Types.VARCHAR);
            statement.setObject(6, obj.gettype(), Types.VARCHAR);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

    } catch (SQLException e) {
    }
        return true;
    
    
    
    }

    @Override
    public Personne trouver(int id) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
   Personne personne = new Personne();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM Personne WHERE IdPersonne = " + id);
      if(result.first())
        personne = new Personne(id, result.getString("nom"), result.getString("prenom"), result.getString("login"), result.getString("password"),  result.getString("type"));         
    } catch (SQLException e) {
    }
    return personne;
    
    
    
    
    }
    
}
