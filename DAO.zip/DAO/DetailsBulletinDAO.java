/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Modele.DetailsBulletin;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 *
 * @author margauxhery
 */
public class DetailsBulletinDAO extends DAO<DetailsBulletin>{

    public DetailsBulletinDAO(Connection conn) throws SQLException, ClassNotFoundException {
        super(conn);
    }

    @Override
    public boolean creer(DetailsBulletin obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "INSERT INTO DetailsBulletin(IdDetailsBulletin,IdBulletin, IdEnseignement, Appreciation) VALUES(?,?,?,?)"
            );
            //Changer les ? par la valeur de l'objet créé pour adapter le java a la requette SQL.
            statement.setObject(1, obj.getIdDetailsBulletin(), Types.INTEGER);
            statement.setObject(2, obj.getIdBulletin(), Types.INTEGER);
            statement.setObject(3, obj.getIdEnseignement(), Types.INTEGER);
            statement.setObject(4, obj.getappreciation(), Types.VARCHAR);

            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

    } catch (SQLException e) {
    }
        return true;
    
    
    
    }

    @Override
    public boolean supprimer(DetailsBulletin obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "DELETE FROM DetailsBulletin WHERE IdDetailsBulletin=?"
            );
            //insert param to change the ? into data
             statement.setObject(1, obj.getIdDetailsBulletin(), Types.INTEGER);
            statement.setObject(2, obj.getIdBulletin(), Types.INTEGER);
            statement.setObject(3, obj.getIdEnseignement(), Types.INTEGER);
            statement.setObject(4, obj.getappreciation(), Types.VARCHAR);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

    } catch (SQLException e) {
    }
        return true;
    
    
    
    }

    @Override
    public boolean actualiser(DetailsBulletin obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
     try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "UPDATE DetailsBulletin SET , Appreciation=? WHERE IdDetailsBulletin=?"
            );
            //insert param to change the ? into data
             statement.setObject(1, obj.getIdDetailsBulletin(), Types.INTEGER);
            statement.setObject(2, obj.getIdBulletin(), Types.INTEGER);
            statement.setObject(3, obj.getIdEnseignement(), Types.INTEGER);
            statement.setObject(4, obj.getappreciation(), Types.VARCHAR);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

    } catch (SQLException e) {
    }
        return true;
    
    
    }

    @Override
    public DetailsBulletin trouver(int id) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
   DetailsBulletin detailsbulletin = new DetailsBulletin();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM DetailsBulletin WHERE IdDetailsBulletin = " + id);
      if(result.first())
        detailsbulletin = new DetailsBulletin(id, result.getInt("IdBulletin"), result.getInt("IdEnseignement"), result.getString("Appreciation")
        );         
    } catch (SQLException e) {
    }
    return detailsbulletin;
    
    
    }
    
}
