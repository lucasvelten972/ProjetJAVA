/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Modele.AnneeScolaire;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
/**
 *
 * @author margauxhery
 */
public class AnneeScolaireDAO extends DAO<AnneeScolaire>{

    public AnneeScolaireDAO(Connection conn) throws SQLException, ClassNotFoundException {
        super(conn);
    }

    @Override
    public boolean creer(AnneeScolaire obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "INSERT INTO AnneeScolaire(IdAnneeScolaire) VALUES(?)"
            );
            //Changer les ? par la valeur de l'objet créé pour adapter le java a la requette SQL.
            statement.setObject(1, obj.getIdAnneeScolaire(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

    } catch (SQLException e) {
    }
        return true;
    }

    @Override
    public boolean supprimer(AnneeScolaire obj) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "DELETE FROM AnneeScolaire WHERE IdAnneeScolaire=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.getIdAnneeScolaire(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

    } catch (SQLException e) {
    }
        return true;
    
    }

    @Override
    public boolean actualiser(AnneeScolaire obj) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "UPDATE AnneeScolaire SET IdAnneeScolaire=?, WHERE IdAnneeScolaire=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.getIdAnneeScolaire(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

    } catch (SQLException e) {
    }
        return true;
    }

    @Override
    public AnneeScolaire trouver(int id) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
         AnneeScolaire anneescolaire = new AnneeScolaire();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM AnneeScolaire WHERE IdAnneeScolaire = " + id);
      if(result.first())
        anneescolaire = new AnneeScolaire(id);         
    } catch (SQLException e) {
    }
    return anneescolaire;
    
    }
    
}
