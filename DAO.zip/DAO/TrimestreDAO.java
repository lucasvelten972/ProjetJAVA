/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Modele.Personne;
import Modele.Trimestre;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 *
 * @author margauxhery
 */
public class TrimestreDAO extends DAO<Trimestre>{

    public TrimestreDAO(Connection conn) throws SQLException, ClassNotFoundException {
        super(conn);
    }

    @Override
    public boolean creer(Trimestre obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "INSERT INTO Trimestre(IdTrimestre,IdAnneeSColaire, Datedebut, Datefin) VALUES(?,?,?,?)"
            );
            //Changer les ? par la valeur de l'objet créé pour adapter le java a la requette SQL.
            statement.setObject(1, obj.getIdTrimestre(), Types.INTEGER);
            statement.setObject(2, obj.getIdAnneeScolaire(), Types.INTEGER);
            statement.setObject(3, obj.getDatedebut(), Types.DATE);
            statement.setObject(4, obj.getDatefin(), Types.DATE);

            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

    } catch (SQLException e) {
    }
        return true;
    
    }

    @Override
    public boolean supprimer(Trimestre obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
   try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "DELETE FROM Trimestre WHERE IdTrimestre=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.getIdTrimestre(), Types.INTEGER);
            statement.setObject(2, obj.getIdAnneeScolaire(), Types.INTEGER);
            statement.setObject(3, obj.getDatedebut(), Types.DATE);
            statement.setObject(4, obj.getDatefin(), Types.DATE);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

    } catch (SQLException e) {
    }
        return true;
    
    
    }

    @Override
    public boolean actualiser(Trimestre obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
     try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "UPDATE Trimestre SET IdAnneeScolaire=?, Datedebut=?, Datefin=? WHERE IdTrimestre=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.getIdTrimestre(), Types.INTEGER);
            statement.setObject(2, obj.getIdAnneeScolaire(), Types.INTEGER);
            statement.setObject(3, obj.getDatedebut(), Types.DATE);
            statement.setObject(4, obj.getDatefin(), Types.DATE);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

    } catch (SQLException e) {
    }
        return true;
    
    
    
    }

    @Override
    public Trimestre trouver(int id) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    Trimestre trimestre = new Trimestre();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM Trimestre WHERE IdTrimestre = " + id);
      if(result.first())
        trimestre = new Trimestre(id, result.getInt("IdAnneeScolaire"), result.getDate("Datedebut"), result.getDate("Datefin"));         
    } catch (SQLException e) {
    }
    return trimestre;
    
    
    
    
    }
    
}
