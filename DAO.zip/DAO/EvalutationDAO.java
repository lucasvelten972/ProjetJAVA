/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;


import Modele.Evaluation;

import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
/**
 *
 * @author margauxhery
 */
public class EvalutationDAO extends DAO<Evaluation>{

    public EvalutationDAO(Connection conn) throws SQLException, ClassNotFoundException {
        super(conn);
    }

    @Override
    public boolean creer(Evaluation obj) {
    try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "INSERT INTO Evaluation(IdEvaluation, IdDetailsBulletin, Note, Appreciation) VALUES(?,?,?,?)"
            );
            //Changer les ? par la valeur de l'objet créé pour adapter le java a la requette SQL.
            statement.setObject(1, obj.getIdEvaluation(), Types.INTEGER);
            statement.setObject(2, obj.getIdDetailsBulletin(), Types.INTEGER);
            statement.setObject(3, obj.getNote(), Types.FLOAT);
            statement.setObject(4, obj.getAppreciation(), Types.VARCHAR);
            
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

    } catch (SQLException e) {
    }
        return true;
    }

    @Override
    public boolean supprimer(Evaluation obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "DELETE FROM Evaluation WHERE IdEvaluation=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.getIdEvaluation(), Types.INTEGER);
            statement.setObject(2, obj.getIdDetailsBulletin(), Types.INTEGER);
            statement.setObject(3, obj.getNote(), Types.FLOAT);
            statement.setObject(4, obj.getAppreciation(), Types.VARCHAR);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

    } catch (SQLException e) {
    }
        return true;
    }

    @Override
    public boolean actualiser(Evaluation obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "UPDATE Evaluation SET IdDetalsBulletin=?, Appreciation=?, Note=?, WHERE IdEvaluation=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.getIdEvaluation(), Types.INTEGER);
            statement.setObject(2, obj.getIdDetailsBulletin(), Types.INTEGER);
            statement.setObject(3, obj.getNote(), Types.FLOAT);
            statement.setObject(4, obj.getAppreciation(), Types.VARCHAR);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

    } catch (SQLException e) {
    }
        return true;
    }

    @Override
    public Evaluation trouver(int id) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                Evaluation evaluation = new Evaluation();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM Evaluation WHERE IdEvaluation = " + id);
      if(result.first())
        evaluation = new Evaluation(
            id,
            result.getInt("IdDetailsBulletin"),
            result.getFloat("Note"),
            result.getString("Appreciation")
        );         
    } catch (SQLException e) {
    }
    return evaluation;
    }
    
}
